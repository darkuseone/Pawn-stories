"""
build.py — собирает ролик из готовых материалов.

Порядок работы:
  1. План кадров. Границы берутся из тайм-кодов ElevenLabs, поэтому
     кадр меняется на конце предложения, а не по секундомеру.
  2. Рендер каждого кадра отдельно, параллельно по числу ядер.
  3. Склейка группами по 12 с переходами, цветокором и оверлеями.
  4. Финальная сшивка без перекодирования, звук, субтитры.

Два цветокора работают одновременно и осознанно:
  синяя семья  → сгенерированные кадры (реконструкция)
  архивный     → подлинные фото и хроника
Так зритель на уровне ощущения отличает реальное от восстановленного.
"""

import json
import math
import os
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

import render
import style as style_mod
from render import W, H, FPS

ROOT = Path(__file__).parent.parent
LUTS = ROOT / "assets" / "luts"
OVERLAYS = ROOT / "assets" / "overlays"
# Подложка по умолчанию. Своя для ролика задаётся полем music в
# спецификации — у каждого канала она обычно разная.
MUSIC = ROOT / "assets" / "music" / "bed.mp3"

SEG_SIZE = 12          # кадров в одной группе склейки

# Движения для фотографий во вступлении: только скольжение и наезд.
# Наклоны там читаются вяло, а статики быть не должно вовсе.
INTRO_MOVES = ["push_in", "pan_right", "pan_left",
               "sweep_in", "push_right", "push_left"]
INTRO = 180.0          # первые три минуты — живое видео


def log(*a):
    print(*a, flush=True)


def cores():
    return max(1, (os.cpu_count() or 2))


# ───────────────────────── НАРЕЗКА ФУТАЖА ─────────────────────────

class ClipCutter:
    """
    Раздаёт КУСКИ стоковых клипов, а не клипы целиком.

    Сток приходит по 14-20 секунд. Если ставить такой клип в кадр целиком,
    зритель двадцать секунд смотрит одну и ту же панораму — ровно то, из-за
    чего ролик и выключают. Поэтому из каждого файла режутся разные куски по
    несколько секунд, и один и тот же файл, попадаясь второй раз, показывает
    другое место.

    Курсор идёт по файлу вперёд и заворачивается в начало, когда упирается
    в конец. Между кусками пропуск в полсекунды: соседние отрезки одного
    файла не должны выглядеть как склейка внутри одного движения камеры.
    """

    GAP = 0.5

    def __init__(self):
        self.length = {}
        self.cursor = {}

    def duration(self, path: Path) -> float:
        key = str(path)
        if key not in self.length:
            r = subprocess.run(
                ["ffprobe", "-v", "error", "-show_entries", "format=duration",
                 "-of", "csv=p=0", key], capture_output=True, text=True)
            try:
                self.length[key] = float(r.stdout.strip())
            except ValueError:
                self.length[key] = 0.0       # не прочиталось — берём с начала
        return self.length[key]

    def take_start(self, path: Path, dur: float) -> float:
        """Отдаёт секунду начала следующего куска этого файла."""
        key = str(path)
        total = self.duration(path)
        start = self.cursor.get(key, 0.0)
        # кусок не помещается в остаток файла — заходим на второй круг
        if total and start + dur > total - 0.15:
            start = 0.0
        self.cursor[key] = start + dur + self.GAP
        return round(start, 3)


class ImagePicker:
    """
    Отдаёт картинку, которая соответствует тому, что звучит в эту секунду.

    Раньше картинки выдавались по кругу: список кончался и начинался заново
    с первой. На ролике в тридцать девять минут при шестидесяти четырёх
    картинках круг проходится четыре раза, и на сороковой минуте зритель
    видит иллюстрацию к первому абзацу — под текст про совсем другое.

    Теперь позиция в списке привязана к позиции на таймлайне. Список
    промптов написан в порядке сценария, поэтому «сорок процентов ролика
    прошло» означает «нужен кадр из сорока процентов списка». Повторы
    остаются (кадров больше, чем картинок), но повторяется соседнее, а не
    начало ролика.

    Окно в два шага в обе стороны нужно, чтобы подряд идущие кадры не
    попадали на одну и ту же картинку: внутри окна берётся наименее
    показанная. Выбор детерминирован — тот же id даёт тот же ролик.
    """

    WINDOW = 2

    def __init__(self, pool, total: float):
        self.pool = pool
        self.total = max(total, 0.001)
        self.used = {}
        self.last = None

    def take(self, t: float):
        n = len(self.pool)
        k = min(n - 1, max(0, int(t / self.total * n)))
        lo, hi = max(0, k - self.WINDOW), min(n, k + self.WINDOW + 1)
        window = [j for j in range(lo, hi) if self.pool[j][0] != self.last]
        if not window:
            window = [k]
        j = min(window, key=lambda x: (self.used.get(x, 0), abs(x - k), x))
        self.used[j] = self.used.get(j, 0) + 1
        self.last = self.pool[j][0]
        return self.pool[j]


# ───────────────────────── ПЛАН КАДРОВ ─────────────────────────

def plan_shots(marks, st, assets, total, job_reject=None):
    """
    Раскладывает материал по таймлайну.

    Ключевое: кадр всегда заканчивается на границе предложения.
    Робот копит предложения, пока не наберётся нужная длительность,
    и режет там. Поэтому склейки попадают в паузы речи.
    """
    def keep(paths, kind, rejected):
        """Выкидывает то, что человек забраковал на листе отбора."""
        out = [p for p in paths if int(p.name.split("_")[1]) not in rejected]
        if rejected:
            log(f"  {kind}: отклонено {len(paths) - len(out)} из {len(paths)}")
        return out

    rej = job_reject or {}
    images = sorted((assets / "images").glob("img_*.jpg"))
    archive = keep(sorted((assets / "archive").glob("arch_*.jpg")),
                   "архив", set(rej.get("arch", [])))
    clips = keep(sorted((assets / "footage").glob("clip_*.mp4")),
                 "футаж", set(rej.get("clip", [])))
    if not images:
        raise SystemExit("нет сгенерированных изображений")

    anchors = set(st.anchor_positions(max(len(marks) // 3, 8)))
    shots, i, idx = [], 0, 0

    # Перемешиваем генерацию и архив в заданной пропорции, вкрапляя
    # подлинные фото равномерно. Если сложить их в конец, весь архив
    # окажется в последней трети ролика.
    img_pool = []
    if archive:
        every = max(2, round(len(images) / max(len(archive), 1)))
        ai = 0
        for n, p in enumerate(images):
            img_pool.append((p, "gen"))
            if n % every == every - 1 and ai < len(archive):
                img_pool.append((archive[ai], "arch"))
                ai += 1
        img_pool += [(p, "arch") for p in archive[ai:]]
    else:
        img_pool = [(p, "gen") for p in images]

    # ВСТУПЛЕНИЕ. Первые минуты — быстрая перебивка: короткие куски видео
    # вперемешку с фотографиями. Ролик, который открывается статичной
    # картинкой на двенадцать секунд, зритель закрывает на первой минуте;
    # но и подряд идущие длинные стоковые клипы работают ровно так же.
    #
    # ЗДЕСЬ КАДР РЕЖЕТСЯ НЕ ПО ПРЕДЛОЖЕНИЯМ. Это сознательное отступление
    # и только для вступления. Предложение у диктора длится в среднем пять
    # с половиной секунд, а нужны куски по две-четыре — уложить их в границы
    # предложений физически нельзя. В теле ролика правило остаётся: там
    # склейки по-прежнему падают в паузы речи.
    #
    # Потолок в треть хронометража нужен ради тестов: на настоящем ролике
    # он не срабатывает и вступление длится ровно заказанные секунды.
    intro_end = min(st.intro_footage_seconds, total * 0.35) if clips else 0.0

    clip_i = 0
    since_clip = 0       # сколько кадров-картинок подряд уже прошло
    next_gap = st.body_clip_every_n_shots
    cutter = ClipCutter()
    picker = ImagePicker(img_pool, total)

    # --- вступление ---
    t = marks[0]["start"] if marks else 0.0
    run_kind, run_len = None, 0
    while clips and t < intro_end:
        # чередуем видео и фото, но не даём трём одинаковым идти подряд
        want_clip = st.rng.random() < st.intro_clip_share
        if run_len >= 2:
            want_clip = run_kind != "clip"
        kind = "clip" if want_clip else "image"
        run_len = run_len + 1 if kind == run_kind else 1
        run_kind = kind

        rng_pair = (st.intro_clip_duration_range if kind == "clip"
                    else st.intro_photo_duration_range)
        dur = round(st.rng.uniform(*rng_pair), 3)
        tr = st.rng.choice(st.transitions)
        # переход во вступлении короткий: длинное растворение съедает
        # весь смысл быстрой перебивки
        trd = round(st.rng.uniform(*st.intro_transition_duration_range), 2)

        if kind == "clip":
            src = clips[clip_i % len(clips)]
            shots.append(dict(kind="clip", file=src,
                              src_start=cutter.take_start(src, dur),
                              start=round(t, 3), duration=dur,
                              transition=tr, transition_dur=trd,
                              effect=st.effect()))
            clip_i += 1
        else:
            src, tag = picker.take(t)
            fr_name, fr = st.framing(src.name)
            shots.append(dict(kind="image", file=src, tag=tag,
                              framing=fr, framing_name=fr_name,
                              start=round(t, 3), duration=dur,
                              # во вступлении по фотографии всегда идёт
                              # скольжение или наезд, статики тут быть не должно
                              move=st.rng.choice(INTRO_MOVES),
                              speed=round(st.rng.uniform(0.9, 1.35), 3),
                              transition=tr, transition_dur=trd,
                              effect=st.effect()))
        t += dur
        idx += 1

    # Тело начинается с предложения, которое в момент t ЕЩЁ ЗВУЧИТ, а не с
    # первого начавшегося после t.
    #
    # Разница не косметическая. Если предложение длинное и накрывает границу
    # вступления, то, пропустив его, робот получает первый кадр тела уже
    # после его конца — а дыру закрывает последним кадром вступления, растянув
    # его. На тестовом прогоне вступление из кусков по три секунды кончалось
    # кадром на шестнадцать секунд: ровно та статика, ради ухода от которой
    # перебивка и делалась.
    while i < len(marks) - 1 and marks[i]["end"] <= t:
        i += 1
    # но начать раньше уже поставленного кадра нельзя — таймлайн не идёт назад
    if shots and marks[i]["start"] <= shots[-1]["start"]:
        i = min(i + 1, len(marks) - 1)

    # --- тело ---
    while i < len(marks):
        is_anchor = idx in anchors
        cfg = st.clip(idx, max(len(marks) // 3, 8), is_anchor=is_anchor)
        want = cfg["duration"]

        first = i
        start = marks[i]["start"]
        # ищем границу предложения БЛИЖАЙШУЮ к желаемой длительности,
        # а не первую её превышающую — иначе кадры systematически
        # получаются длиннее задуманного
        j, best, best_err = i, i, abs(marks[i]["end"] - start - want)
        while j < len(marks) - 1 and marks[j]["end"] - start < want * 1.6:
            j += 1
            err = abs(marks[j]["end"] - start - want)
            if err < best_err:
                best, best_err = j, err
        end = marks[best]["end"]
        i = best + 1

        # Кому достаётся кадр — футажу или картинке.
        #
        # Во вступлении картинок нет вообще: пока не кончились заказанные
        # секунды, каждый кадр это видео.
        #
        # Дальше по телу вставка идёт примерно каждый n-й кадр. Именно
        # ПРИМЕРНО: шаг гуляет на единицу в обе стороны, потому что ровный
        # ритм «через три на четвёртый» читается как машинный так же
        # отчётливо, как нарезка по секундомеру.
        #
        # Якорный кадр под футаж не отдаём: он намеренно длинный, до двадцати
        # секунд, а сток редко бывает длиннее пятнадцати и уходил бы в петлю.
        # Долгий кадр — это всегда изображение.
        take_clip = bool(clips) and not is_anchor and since_clip >= next_gap

        if take_clip:
            src = clips[clip_i % len(clips)]
            shots.append(dict(kind="clip", file=src,
                              src_start=cutter.take_start(src, end - start),
                              start=start, duration=round(end - start, 3),
                              **{k: cfg[k] for k in
                                 ("transition", "transition_dur", "effect")}))
            clip_i += 1
            since_clip = 0
            n = st.body_clip_every_n_shots
            next_gap = max(1, n + st.rng.choice([-1, 0, 0, 1]))
        else:
            since_clip += 1
            src, tag = picker.take(start)
            fr_name, fr = st.framing(src.name)
            shots.append(dict(kind="image", file=src, tag=tag,
                              framing=fr, framing_name=fr_name,
                              start=start, duration=round(end - start, 3),
                              **{k: cfg[k] for k in
                                 ("move", "speed", "transition",
                                  "transition_dur", "effect")}))
        idx += 1

    # Кадр держится до НАЧАЛА следующего, а не до конца своего последнего
    # предложения. Границы остаются теми же (это те же тайм-коды), но паузы
    # между предложениями теперь покрыты кадром. Иначе они не покрыты ничем,
    # и картинка уезжает вперёд звука на сумму всех пауз.
    for cur, nxt in zip(shots, shots[1:]):
        cur["duration"] = round(nxt["start"] - cur["start"], 3)
    # хвост: последний кадр дотягиваем до конца звука
    if shots:
        shots[-1]["duration"] = round(max(total - shots[-1]["start"], 0.1), 3)
    return shots


# ───────────────────────── НАСТРОЙКИ ИЗ JSON ─────────────────────────

# Что можно переопределить блоком style_override в спецификации ролика.
# Ключ слева — как это называется в JSON, значение — поле StyleEngine.
# Список закрытый намеренно: опечатка в имени должна быть замечена, а не
# молча проигнорирована.
OVERRIDABLE = {
    "haze_enabled":              "haze_enabled",
    "sparks_enabled":            "sparks_enabled",
    "spark_opacity":             "spark_opacity",
    "spark_speed_px_sec":        "spark_speed_px_sec",
    "spark_flicker":             "spark_flicker",
    "grain":                     "grain",
    "vignette":                  "vignette",
    "transitions":               "transitions",
    "transition_duration_range": "tr_dur_range",
    "hard_cut_probability":      "hard_cut_probability",
    "intro_footage_seconds":     "intro_footage_seconds",
    "intro_clip_duration_range": "intro_clip_duration_range",
    "intro_photo_duration_range": "intro_photo_duration_range",
    "intro_clip_share":          "intro_clip_share",
    "intro_transition_duration_range": "intro_transition_duration_range",
    "body_clip_every_n_shots":   "body_clip_every_n_shots",
    "effects_enabled":           "effects_enabled",
    "effects":                   "effects",
    "effect_probability":        "effect_probability",
    # Цветокор ролика. Без этого поля он выпадает случайно из семьи LUTS в
    # style.py — для канала с другим настроением это не подходит.
    "lut":                       "lut",
    "archive_lut":               "archive_lut",
}

# Поля, которые не присваиваются напрямую, а перебрасывают жребий.
# base_dur и decel рисуются один раз при создании движка и задают темп всего
# ролика; поменять их можно только новым броском в заданных границах.
REDRAW = {
    "base_duration_range": "base_dur",
    "deceleration_range":  "decel",
}

PAIRS = {"spark_speed_px_sec", "spark_flicker", "transition_duration_range",
         "intro_clip_duration_range", "intro_photo_duration_range",
         "intro_transition_duration_range"}


def apply_style_override(st, job):
    """
    Накладывает блок style_override из спецификации поверх StyleEngine.

    Смысл ровно один: менять картинку правкой JSON, без правки кода.
    Блока нет — всё работает на умолчаниях, как раньше.

    fps стоит особняком. Это не поле стиля, а константа модуля render,
    от которой считаются и длина клипа в кадрах, и запас PAD, и частота
    слоя искр. Поэтому её правим до того, как что-либо из этого посчитано,
    и правим во всех трёх местах сразу.
    """
    ov = job.get("style_override") or {}
    if not ov:
        return st

    # ключи с подчёркивания — комментарии, так заведено в самих спецификациях
    unknown = [k for k in ov
               if not k.startswith("_") and k not in OVERRIDABLE
               and k not in REDRAW and k != "fps"]
    if unknown:
        raise SystemExit(
            "style_override: неизвестные поля " + ", ".join(sorted(unknown)) +
            "\nдопустимые: " + ", ".join(
                sorted(list(OVERRIDABLE) + list(REDRAW) + ["fps"])))

    if "fps" in ov:
        fps = int(ov["fps"])
        render.FPS = fps
        globals()["FPS"] = fps
        globals()["PAD"] = round(2 / fps, 3)
        log(f"  fps -> {fps}")

    # Бросок в новых границах. Случайность сохраняется — уходит только
    # привязка к диапазону, зашитому в код.
    for key, field in REDRAW.items():
        if key in ov:
            lo, hi = ov[key]
            setattr(st, field, round(st.rng.uniform(float(lo), float(hi)), 3))
            log(f"  {key} -> {ov[key]} => {getattr(st, field)}")

    for key, field in OVERRIDABLE.items():
        if key not in ov:
            continue
        val = ov[key]
        if key in PAIRS:
            val = tuple(val)
        if key == "effects":
            bad = [e for e in val if e not in style_mod.EFFECTS]
            if bad:
                raise SystemExit(
                    "style_override.effects: нет таких эффектов " +
                    ", ".join(bad) + "\nесть: " +
                    ", ".join(sorted(style_mod.EFFECTS)))
        setattr(st, field, val)
        log(f"  {key} -> {val}")
    return st


def xfade_dur(shot):
    """Сколько таймлайна съест переход после этого кадра."""
    return 0.04 if shot["transition"] == "cut" else shot["transition_dur"]


PAD = round(2 / FPS, 3)     # два кадра запаса в хвосте каждого клипа


def set_render_durations(shots):
    """
    xfade склеивает соседние кадры ВНАХЛЁСТ: каждый переход вычитает свою
    длительность из общего таймлайна. Если рендерить кадр ровно на его
    предложения, картинка уходит вперёд звука на сумму всех переходов —
    на тестовом ролике это 8 секунд из 67, на 38-минутном около шести
    минут, и -shortest в mux молча срезает конец начитки.

    Поэтому кадр рендерится длиннее: предложения + переход + два кадра
    запаса. Запас обязателен. ffmpeg отдаёт целое число кадров и округляет
    длину ВНИЗ, то есть клип выходит короче заказанного почти на кадр.
    xfade при этом просит кадры за концом клипа и молча обрывает всю группу:
    на прогоне это дало 13.9 секунды вместо 114.8 при нулевом коде возврата.
    Особенно легко ловится на 'cut' — там нахлёст 0.04 с приходится ровно
    на последний кадр.

    Хвост запаса не виден: xfade отбрасывает всё, что осталось от кадра
    после перехода. У последнего кадра группы перехода нет (группы сшиваются
    встык), поэтому и запаса нет — иначе он оказался бы на экране.
    """
    for gi in range(0, len(shots), SEG_SIZE):
        group = shots[gi:gi + SEG_SIZE]
        for k, sh in enumerate(group):
            extra = 0.0 if k == len(group) - 1 else xfade_dur(sh) + PAD
            sh["render_dur"] = round(sh["duration"] + extra, 3)


# ───────────────────────── РЕНДЕР ─────────────────────────

def render_one(args):
    n, sh, tmp = args
    out = tmp / f"clip_{n:04d}.mp4"
    if out.exists():
        return out
    if sh["kind"] == "clip":
        render.render_footage_clip(Path(sh["file"]), out, sh["render_dur"],
                                   start=sh.get("src_start", 0.0),
                                   effect=sh.get("effect"))
    else:
        prep = tmp / f"prep_{n:04d}.jpg"
        render.prepare_image(Path(sh["file"]), prep, sh["framing"])
        render.render_clip(prep, out, sh["move"], sh["speed"], sh["render_dur"],
                           effect=sh.get("effect"))
        prep.unlink(missing_ok=True)
    return out


def grade_for(shot, st):
    """Подлинный архив получает архивный грейд, генерация — синий."""
    if shot.get("tag") == "arch":
        return LUTS / f"{st.archive_lut}.cube"
    return LUTS / f"{st.lut}.cube"


def film_look():
    """
    Киношная приглушённая база поверх LUT.

    curves приподнимает тени: чёрный перестаёт быть провалом и становится
    матовой плёночной растяжкой — именно это отличает «кино» от «фото с
    телефона». Синий поднят чуть сильнее красного, поэтому тени уходят в
    холод, а света остаются тёплыми: та самая тёплая-холодная разводка.
    Верх подтянут вниз, чтобы белое не выбивало.
    eq снимает насыщенность: атмосфера приглушённая, а не открыточная.

    ПОРЯДОК ЗДЕСЬ ВАЖЕН и стоил отдельного замера. Сначала eq, потом curves.
    Наоборот не работает: contrast у eq утягивает тени вниз сильнее, чем
    curves их поднимает, и вместо матовой растяжки получается ровно то же
    проваленное чёрное, только с потерянной насыщенностью. Замер на тестовом
    кадре: тени 31 -> 26 при обратном порядке против 31 -> 41 при этом.

    Одна строка на весь ролик, крутится здесь. Теплее — поднимаем хвост b,
    глубже тени — уменьшаем первое число в curves.
    """
    return (
        "eq=saturation=0.82:contrast=0.97,"
        "curves=r='0/0.048 0.5/0.500 1/0.970'"
        ":g='0/0.051 0.5/0.500 1/0.965'"
        ":b='0/0.070 0.5/0.505 1/0.946'"
    )


def join(group, out: Path, lut: Path, st, sparks):
    ins = " ".join(f'-i "{c["file"]}"' for c in group)
    if sparks is not None:
        ins += f' -stream_loop -1 -i "{sparks}"'
    sp = len(group)

    fc, prev, off = [], "0", 0.0
    for k in range(1, len(group)):
        tr = group[k - 1]
        d = xfade_dur(tr)
        name = "fade" if tr["transition"] == "cut" else tr["transition"]
        # смещение — ровно граница предложения, а не длина файла: кадр k
        # встаёт на ту секунду звука, где начинается его первое предложение
        off += tr["duration"]
        fc.append(f'[{prev}][{k}]xfade=transition={name}:'
                  f'duration={d:.3f}:offset={off:.3f}[x{k}]')
        prev = f"x{k}"

    chain = [f'lut3d=file={lut}', film_look()]
    fc.append(f'[{prev}]' + ",".join(chain) + '[graded]')
    # Слой один — искры, и его может не быть вовсе. Дымку с канала убрали:
    # атмосферность уже в LUT через подъём чёрного, второй слой её только мылил.
    if sparks is not None:
        flip = ",hflip" if st.spark_flip else ""
        # setpts здесь нет: скорость искр задана в пикселях в секунду и
        # запечена прямо в петлю. Растягивать её ещё и по времени значило бы
        # умножать одно на другое и терять контроль над числом.
        fc.append(f'[{sp}:v]scale={W}:{H}{flip},setsar=1[spv]')
        # all_opacity — единственная ручка силы наложения
        fc.append(f'[graded][spv]blend=all_mode=screen:'
                  f'all_opacity={st.spark_opacity}:shortest=1[h2]')
        last = "h2"
    else:
        last = "graded"

    post = []
    if st.grain:
        post.append(f"noise=alls={st.grain}:allf=t+u")
    if st.vignette:
        post.append(f"vignette=PI/{st.vignette:.2f}")
    post.append("setsar=1")
    fc.append(f'[{last}]' + ",".join(post) + '[out]')

    cmd = (f'ffmpeg -y {ins} -filter_complex "{";".join(fc)}" -map "[out]" '
           f'-c:v libx264 -crf 20 -preset veryfast -pix_fmt yuv420p -an "{out}"')
    subprocess.run(cmd, shell=True, check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def ensure_overlays(st):
    """Готовый слой искр, либо None если искры выключены спецификацией."""
    if not st.sparks_enabled:
        log("  искры выключены спецификацией")
        return None
    OVERLAYS.mkdir(parents=True, exist_ok=True)
    sp = OVERLAYS / f"sparks_{st.sparks_variant}.mp4"
    if not sp.exists():
        # Штатно файл лежит в репозитории и этот код не выполняется.
        # Он остаётся страховкой: генерация трёх вариантов занимает минуты,
        # и платить их каждым прогоном не за что.
        log("  искр нет, генерирую (разово)")
        import overlays
        overlays.make_sparks(sp, seconds=20, seed=st.sparks_variant,
                             count=overlays.SPARK_COUNTS[st.sparks_variant - 1],
                             size_range=tuple(st.spark_size),
                             px_sec=tuple(st.spark_speed_px_sec),
                             flicker=tuple(st.spark_flicker))
    return sp


# ───────────────────────── ГЛАВНОЕ ─────────────────────────

def main(job_path):
    job = json.loads(Path(job_path).read_text(encoding="utf-8"))
    base = Path("work") / job["id"]
    assets = base / "assets"
    tmp = base / "tmp"
    out = base / "out"
    for d in (tmp, out):
        d.mkdir(parents=True, exist_ok=True)

    st = style_mod.StyleEngine(job["id"],
                               recent_luts=job.get("recent_luts"),
                               recent_openings=job.get("recent_openings"))
    st.archive_lut = job.get("archive_lut", "archive_sepia")
    # style_override накладывается СРАЗУ после создания движка: ниже от этих
    # полей зависят и план кадров, и запас PAD, и генерация искр.
    if job.get("style_override"):
        log("── настройки из спецификации")
        apply_style_override(st, job)
    log("стиль:", json.dumps(st.summary(), ensure_ascii=False))

    marks = json.loads((assets / "marks.json").read_text())
    total = json.loads((assets / "state.json").read_text())["total_audio"]

    log("── план кадров")
    shots = plan_shots(marks, st, assets, total, job.get("reject"))
    set_render_durations(shots)
    log(f"  {len(shots)} кадров на {total/60:.1f} мин, "
        f"средний {total/len(shots):.1f} сек")
    (out / "shots.json").write_text(json.dumps(
        [{k: str(v) for k, v in s.items() if k != 'framing'} for s in shots],
        indent=1, ensure_ascii=False))

    log("── рендер кадров")
    with ThreadPoolExecutor(max_workers=cores()) as ex:
        files = list(ex.map(render_one,
                            [(n, s, tmp) for n, s in enumerate(shots)]))
    for s, f in zip(shots, files):
        s["file"] = f

    log("── склейка и цветокор")
    sparks = ensure_overlays(st)
    segs = []
    for gi in range(0, len(shots), SEG_SIZE):
        group = shots[gi:gi + SEG_SIZE]
        seg = tmp / f"seg_{gi//SEG_SIZE:03d}.mp4"
        if not seg.exists():
            lut = grade_for(group[0], st)
            join(group, seg, lut, st, sparks)
        segs.append(seg)
        log(f"  группа {gi//SEG_SIZE + 1}/{math.ceil(len(shots)/SEG_SIZE)}")

    log("── сшивка")
    silent = tmp / "silent.mp4"
    render.concat_segments(segs, silent)

    log("── звук")
    mixed = tmp / "audio.m4a"
    bed = Path(job["music"]) if job.get("music") else MUSIC
    if not bed.is_absolute():
        bed = ROOT / bed
    if not bed.exists():
        raise SystemExit(f"нет музыкальной подложки {bed}")
    log(f"  подложка: {bed.name}")
    render.build_audio(assets / "voice_full.m4a", bed, mixed, total,
                       bed_gain_db=job.get("bed_gain_db", -26.0))

    log("── финал")
    render.mux(silent, mixed, out / "final.mp4")
    render.write_srt(marks, out / "subs.srt")
    log("готово:", out / "final.mp4")


if __name__ == "__main__":
    main(sys.argv[1])
